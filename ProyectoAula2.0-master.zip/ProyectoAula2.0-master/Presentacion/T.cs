﻿namespace Presentacion
{
    internal class T
    {
    }
}